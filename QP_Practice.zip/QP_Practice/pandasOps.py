import pandas as pd 

df = pd.read_csv("QP_Practice/student.csv")
print(df.head(5))

print("columns :",df.columns.tolist())