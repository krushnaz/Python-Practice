# import pandas as pd 
# import numpy as np

# employee = {
#     'EID' :[23201,20302,23203],
#     'ENAME':['Shubham','Meera','Rohit'],
#     'HRA':[4000,3000,2500],
#     'TA':[3000,np.nan,3000],
#     'DA':[8000,8500,8200]
# }

# # df = pd.DataFrame(employee)
# # csv_file = df.to_csv("Employee.csv")

# df = pd.read_csv('./Employee.csv')
# # print(df)
# # Indexing and Selection:
# # select_many = df[['ENAME','DA']]
# # print(select_many)

# dfLoc = df.loc[1]
# print(dfLoc)


list1 = [1, 2, 3]
list2 = [4, 5, 6]
tuple1 = (7, 8, 9)
tuple2 = (10, 11, 12)
print(list1 + list2)  # Output: [1, 2, 3, 4, 5, 6]
print(tuple1 + tuple2) 