# def countUpTo(n) :
#     count = 0
#     i = 0
#     while count <= n :
#         yield count
#         count +=1

# counted_values = countUpTo(5)
# for i in counted_values :
#     print(i)
    
    
# def febonacci() :
#     a,b = 0,1
#     while True :
#         yield a
#         a,b = b, a + b
# fib = febonacci()

# for i in range(10) :
#     print(next(fib))
