base = 400
exponent = 1.05

power = lambda x,y : x ** y

print(power(base,exponent))

